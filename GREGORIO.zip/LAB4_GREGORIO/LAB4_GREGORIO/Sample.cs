﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_GREGORIO
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Julie";
            lastname = "Gregorio";
        
        }
    }
}
