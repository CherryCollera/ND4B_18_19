﻿

namespace GREGORIO_CABER
{
    class Reminder
    {
               public void ComputeReminder()
    {
        DeclareVariables.reminder = DeclareVariables.num1 % DeclareVariables.num2;
    }
}
}
