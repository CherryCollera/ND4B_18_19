﻿
namespace GREGORIO_CABER
{
    class DeclareVariables
    {
        public static double num1, num2, sum, difference, product, quotient, reminder;

    }
}
