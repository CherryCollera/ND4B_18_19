﻿

namespace GREGORIO_CABER
{
    class Product
    {
                public void ComputeProduct()
    {
        DeclareVariables.product = DeclareVariables.num1 * DeclareVariables.num2;
    }
}
}