﻿
namespace GREGORIO_CABER
{
    class Input
    {
        public void InputValues()
        {
            System.Console.Write("Enter first number:   ");
            DeclareVariables.num1 = System.Convert.ToInt32(System.Console.ReadLine());
            System.Console.Write("\nEnter second number:  ");
            DeclareVariables.num2 = System.Convert.ToDouble(System.Console.ReadLine());

       
        }

    }
}