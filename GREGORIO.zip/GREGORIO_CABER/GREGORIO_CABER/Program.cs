﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GREGORIO_CABER
{
    class Program
    {
        static void Main(string[] args){

                Input i = new Input();
                i.InputValues();
                
                Sum s = new Sum();
                s.ComputeSum();
                System.Console.WriteLine("\nSum = "+ DeclareVariables.sum);
                System.Console.ReadLine();
                
                Difference d = new Difference();
                d.ComputeDifference();
                System.Console.WriteLine("\nDifference = " +  DeclareVariables.difference);
                System.Console.ReadLine();

                Product p = new Product();
                p.ComputeProduct();
                System.Console.WriteLine("\nProduct = " + DeclareVariables.product);
                System.Console.ReadLine();

                Quotient q = new Quotient();
                q.ComputeQuotient();
                System.Console.WriteLine("\nQuotient = " + DeclareVariables.quotient);
                System.Console.ReadLine();

                Reminder r = new Reminder();
                r.ComputeReminder();
                System.Console.WriteLine("\nReminder = " + DeclareVariables.reminder);
                System.Console.ReadLine();
        }
    }
}
