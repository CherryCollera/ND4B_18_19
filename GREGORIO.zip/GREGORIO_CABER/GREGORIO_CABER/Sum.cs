﻿
namespace GREGORIO_CABER
{

    class Sum
    {
        public void ComputeSum()
    {
        DeclareVariables.sum = DeclareVariables.num1 + DeclareVariables.num2;
    }
}
}