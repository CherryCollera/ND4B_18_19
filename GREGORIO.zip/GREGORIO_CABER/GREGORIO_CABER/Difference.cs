﻿
namespace GREGORIO_CABER
{
    class Difference
    {
                public void ComputeDifference()
    {
        DeclareVariables.difference = DeclareVariables.num1 - DeclareVariables.num2;
    }
}
}