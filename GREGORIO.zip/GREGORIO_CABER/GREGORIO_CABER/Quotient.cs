﻿

namespace GREGORIO_CABER
{
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVariables.quotient = DeclareVariables.num1 / DeclareVariables.num2;
        }
    }
}
