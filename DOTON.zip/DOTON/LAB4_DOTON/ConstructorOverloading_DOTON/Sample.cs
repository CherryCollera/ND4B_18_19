﻿
namespace ConstructorOverloading_DOTON
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Kamille";
            lastname = "DOTON";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
            {

            }
        }
    }
}
