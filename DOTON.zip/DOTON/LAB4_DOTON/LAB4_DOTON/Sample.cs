﻿

namespace LAB4_DOTON
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Lauryn";
            lastname = "Evangelista";
        }
    }
}
