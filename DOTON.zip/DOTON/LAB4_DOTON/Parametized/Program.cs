﻿using System;
namespace Parametized
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample("Bryan", "Isidro");

            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
