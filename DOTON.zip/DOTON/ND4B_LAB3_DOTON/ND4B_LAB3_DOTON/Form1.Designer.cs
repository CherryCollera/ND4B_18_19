﻿namespace ND4B_LAB3_DOTON
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btExit = new System.Windows.Forms.Button();
            this.btequal = new System.Windows.Forms.Button();
            this.btquotient = new System.Windows.Forms.Button();
            this.btproduct = new System.Windows.Forms.Button();
            this.btminus = new System.Windows.Forms.Button();
            this.btplus = new System.Windows.Forms.Button();
            this.btclear = new System.Windows.Forms.Button();
            this.btdot = new System.Windows.Forms.Button();
            this.bt0 = new System.Windows.Forms.Button();
            this.bt9 = new System.Windows.Forms.Button();
            this.bt8 = new System.Windows.Forms.Button();
            this.bt7 = new System.Windows.Forms.Button();
            this.bt6 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btExit
            // 
            this.btExit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExit.Location = new System.Drawing.Point(30, 332);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(57, 36);
            this.btExit.TabIndex = 100;
            this.btExit.Text = "Exit";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // btequal
            // 
            this.btequal.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btequal.Location = new System.Drawing.Point(234, 332);
            this.btequal.Name = "btequal";
            this.btequal.Size = new System.Drawing.Size(56, 36);
            this.btequal.TabIndex = 99;
            this.btequal.Text = "=";
            this.btequal.UseVisualStyleBackColor = true;
            this.btequal.Click += new System.EventHandler(this.btequal_Click);
            // 
            // btquotient
            // 
            this.btquotient.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btquotient.Location = new System.Drawing.Point(234, 283);
            this.btquotient.Name = "btquotient";
            this.btquotient.Size = new System.Drawing.Size(57, 36);
            this.btquotient.TabIndex = 98;
            this.btquotient.Text = "/";
            this.btquotient.UseVisualStyleBackColor = true;
            this.btquotient.Click += new System.EventHandler(this.btquotient_Click);
            // 
            // btproduct
            // 
            this.btproduct.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btproduct.Location = new System.Drawing.Point(234, 231);
            this.btproduct.Name = "btproduct";
            this.btproduct.Size = new System.Drawing.Size(57, 36);
            this.btproduct.TabIndex = 97;
            this.btproduct.Text = "*";
            this.btproduct.UseVisualStyleBackColor = true;
            this.btproduct.Click += new System.EventHandler(this.btproduct_Click);
            // 
            // btminus
            // 
            this.btminus.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btminus.Location = new System.Drawing.Point(234, 186);
            this.btminus.Name = "btminus";
            this.btminus.Size = new System.Drawing.Size(57, 36);
            this.btminus.TabIndex = 96;
            this.btminus.Text = "-";
            this.btminus.UseVisualStyleBackColor = true;
            this.btminus.Click += new System.EventHandler(this.btminus_Click);
            // 
            // btplus
            // 
            this.btplus.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btplus.Location = new System.Drawing.Point(234, 134);
            this.btplus.Name = "btplus";
            this.btplus.Size = new System.Drawing.Size(57, 36);
            this.btplus.TabIndex = 95;
            this.btplus.Text = "+";
            this.btplus.UseVisualStyleBackColor = true;
            this.btplus.Click += new System.EventHandler(this.btplus_Click);
            // 
            // btclear
            // 
            this.btclear.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btclear.Location = new System.Drawing.Point(156, 283);
            this.btclear.Name = "btclear";
            this.btclear.Size = new System.Drawing.Size(57, 36);
            this.btclear.TabIndex = 94;
            this.btclear.Text = "Clear";
            this.btclear.UseVisualStyleBackColor = true;
            this.btclear.Click += new System.EventHandler(this.btclear_Click);
            // 
            // btdot
            // 
            this.btdot.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btdot.Location = new System.Drawing.Point(93, 283);
            this.btdot.Name = "btdot";
            this.btdot.Size = new System.Drawing.Size(57, 36);
            this.btdot.TabIndex = 93;
            this.btdot.Text = ".";
            this.btdot.UseVisualStyleBackColor = true;
            this.btdot.Click += new System.EventHandler(this.btdot_Click);
            // 
            // bt0
            // 
            this.bt0.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt0.Location = new System.Drawing.Point(30, 283);
            this.bt0.Name = "bt0";
            this.bt0.Size = new System.Drawing.Size(57, 36);
            this.bt0.TabIndex = 92;
            this.bt0.Text = "0";
            this.bt0.UseVisualStyleBackColor = true;
            this.bt0.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt9
            // 
            this.bt9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt9.Location = new System.Drawing.Point(156, 231);
            this.bt9.Name = "bt9";
            this.bt9.Size = new System.Drawing.Size(57, 36);
            this.bt9.TabIndex = 91;
            this.bt9.Text = "9";
            this.bt9.UseVisualStyleBackColor = true;
            this.bt9.Click += new System.EventHandler(this.bt9_Click);
            // 
            // bt8
            // 
            this.bt8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt8.Location = new System.Drawing.Point(93, 231);
            this.bt8.Name = "bt8";
            this.bt8.Size = new System.Drawing.Size(57, 36);
            this.bt8.TabIndex = 90;
            this.bt8.Text = "8";
            this.bt8.UseVisualStyleBackColor = true;
            this.bt8.Click += new System.EventHandler(this.bt8_Click);
            // 
            // bt7
            // 
            this.bt7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt7.Location = new System.Drawing.Point(30, 231);
            this.bt7.Name = "bt7";
            this.bt7.Size = new System.Drawing.Size(57, 36);
            this.bt7.TabIndex = 89;
            this.bt7.Text = "7";
            this.bt7.UseVisualStyleBackColor = true;
            this.bt7.Click += new System.EventHandler(this.bt7_Click);
            // 
            // bt6
            // 
            this.bt6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt6.Location = new System.Drawing.Point(156, 186);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(57, 36);
            this.bt6.TabIndex = 88;
            this.bt6.Text = "6";
            this.bt6.UseVisualStyleBackColor = true;
            this.bt6.Click += new System.EventHandler(this.bt6_Click);
            // 
            // bt5
            // 
            this.bt5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt5.Location = new System.Drawing.Point(93, 186);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(57, 36);
            this.bt5.TabIndex = 87;
            this.bt5.Text = "5";
            this.bt5.UseVisualStyleBackColor = true;
            this.bt5.Click += new System.EventHandler(this.bt5_Click);
            // 
            // bt4
            // 
            this.bt4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt4.Location = new System.Drawing.Point(30, 186);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(57, 36);
            this.bt4.TabIndex = 86;
            this.bt4.Text = "4";
            this.bt4.UseVisualStyleBackColor = true;
            this.bt4.Click += new System.EventHandler(this.bt4_Click);
            // 
            // bt3
            // 
            this.bt3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt3.Location = new System.Drawing.Point(156, 134);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(57, 36);
            this.bt3.TabIndex = 85;
            this.bt3.Text = "3";
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.bt3_Click);
            // 
            // bt2
            // 
            this.bt2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt2.Location = new System.Drawing.Point(93, 134);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(57, 36);
            this.bt2.TabIndex = 84;
            this.bt2.Text = "2";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // bt1
            // 
            this.bt1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt1.Location = new System.Drawing.Point(30, 134);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(57, 36);
            this.bt1.TabIndex = 83;
            this.bt1.Text = "1";
            this.bt1.UseVisualStyleBackColor = true;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(30, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(261, 24);
            this.textBox1.TabIndex = 82;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 55);
            this.label1.TabIndex = 81;
            this.label1.Text = "Calculator";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 379);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.btequal);
            this.Controls.Add(this.btquotient);
            this.Controls.Add(this.btproduct);
            this.Controls.Add(this.btminus);
            this.Controls.Add(this.btplus);
            this.Controls.Add(this.btclear);
            this.Controls.Add(this.btdot);
            this.Controls.Add(this.bt0);
            this.Controls.Add(this.bt9);
            this.Controls.Add(this.bt8);
            this.Controls.Add(this.bt7);
            this.Controls.Add(this.bt6);
            this.Controls.Add(this.bt5);
            this.Controls.Add(this.bt4);
            this.Controls.Add(this.bt3);
            this.Controls.Add(this.bt2);
            this.Controls.Add(this.bt1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Button btequal;
        private System.Windows.Forms.Button btquotient;
        private System.Windows.Forms.Button btproduct;
        private System.Windows.Forms.Button btminus;
        private System.Windows.Forms.Button btplus;
        private System.Windows.Forms.Button btclear;
        private System.Windows.Forms.Button btdot;
        private System.Windows.Forms.Button bt0;
        private System.Windows.Forms.Button bt9;
        private System.Windows.Forms.Button bt8;
        private System.Windows.Forms.Button bt7;
        private System.Windows.Forms.Button bt6;
        private System.Windows.Forms.Button bt5;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
    }
}

