﻿
namespace LAB4_RMENDOZA
{

    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Cherry";
            lastname = "Collera";
        }
    }
}