﻿

namespace ConstructorOverloading.cs
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Cherry";
            lastname = "Collera";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
            {
            }
        }
    }
}