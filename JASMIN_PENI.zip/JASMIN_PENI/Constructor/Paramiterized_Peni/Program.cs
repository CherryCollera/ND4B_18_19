﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paramiterized_Peni
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Parameterized Constructors");
            Console.WriteLine("");
            sample s = new sample("JASMIN JOY", "TORRES PENI ");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.secondname);
            Console.ReadLine();
        }
    }
}
