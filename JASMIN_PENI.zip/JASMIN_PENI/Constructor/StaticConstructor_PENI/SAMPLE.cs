﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor_PENI
{
    class SAMPLE
    {

        public string firstname, secondname;
        static SAMPLE()
        {
            System.Console.WriteLine("Static Constructor");
        }

        public SAMPLE()
        {

            firstname = "JASMIN";
            secondname = "JOY";
        }
    }
}
