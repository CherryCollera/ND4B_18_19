﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor_PENI
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE s = new SAMPLE("JASMIN JOY", "TORRES PENI");

            Console.WriteLine("\n" + s.firstname + "\n\n" + s.secondname);
            Console.ReadLine();
        }
    }
}
