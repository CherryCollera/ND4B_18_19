﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingConstructor_PENI
{
    class SAMPLE
    {
         public string firstname, secondname;
        public SAMPLE() 
        {
            firstname = " JASMIN ";
            secondname = "JOY";
    }
    }
}
