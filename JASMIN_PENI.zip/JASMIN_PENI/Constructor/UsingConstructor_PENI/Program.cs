﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingConstructor_PENI
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE s = new SAMPLE();
            Console.WriteLine("Default Constructors");
            Console.WriteLine("");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.secondname);
            Console.ReadLine();
        }
    }
}
