﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor_PENI
{
    class Program
    {
        static void Main(string[] args)
        {
            sample s = new sample(" JASMIN JOY", "TORRES PENI ");
            sample s1 = new sample();
            Console.WriteLine("copy Constructors");
            Console.WriteLine("");
            Console.WriteLine(s);
            Console.WriteLine("\n" + s1.firstname + "\n\n" + s1.secondname);
            Console.ReadLine();
        }
    }
}
