﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor_PENI
{
    class sample
    {
        public string firstname, secondname;
        public sample()
        {
            firstname = "JASMIN";
            secondname = "JOY";
        }

        public sample(string j, string p)
        {

            firstname = j;
            secondname = p;
        }
    }
}
