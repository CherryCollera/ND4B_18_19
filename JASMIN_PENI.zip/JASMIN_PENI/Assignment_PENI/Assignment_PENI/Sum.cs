﻿

namespace Assignment_PENI
{
    class Sum
    {
        public void ComputeSum()
        {
            DeclareVariable.sum = DeclareVariable.num1 + DeclareVariable.num2;
        }
    }
}
