﻿

namespace Assignment_PENI
{
    class Remainder
    {
        public void ComputeRemainder()
        {
            DeclareVariable.remainder = DeclareVariable.num1 % DeclareVariable.num2;
        }
    }
}
