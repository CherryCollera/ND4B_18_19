﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading
{

    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Cherry";
            lastname = "Collera";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
            {
            }
        }
    }
}