﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ConstructorOverloading_ISIDROJ
{
    class Sample
    {
        
     public string firstname, lastname;
        public Sample()
        {
            firstname = "JERCIE";
            lastname = "ISIDRO";
        }

        public Sample(string j, string i)
        {

            firstname = j;
            lastname = i;
        }
    }
}
