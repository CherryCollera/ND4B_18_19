﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor_ISIDROJ
{
    class Sample
    {
        public string firstname, lastname;
        public Sample(string j, string i)
        {
            firstname = j;
            lastname = i;
        }

        private Sample()
        {

            Console.WriteLine(" Private Constructor with no prameters");
        }
    }
}
