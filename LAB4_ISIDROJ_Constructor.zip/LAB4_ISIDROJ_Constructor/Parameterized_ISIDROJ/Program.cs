﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_ISIDROJ
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Parameterized Constructors");
            Console.WriteLine("");
            Sample s = new Sample("JERCIE", "ISIDRO");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
