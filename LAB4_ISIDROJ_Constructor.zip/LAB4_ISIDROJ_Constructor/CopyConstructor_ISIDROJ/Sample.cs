﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor_ISIDROJ
{
    class Sample
    {
         public string firstname, lastname;
         public Sample(string j, string i)
        {
            firstname = j;
            lastname = i;
        }

        public Sample(Sample s)
        {

            firstname = s.firstname;
            lastname = s.lastname;
        }
    }
}
