﻿namespace LAB4_ISIDROB
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Bryan Albert";
            lastname = "Isidro";
        }
    }
}
