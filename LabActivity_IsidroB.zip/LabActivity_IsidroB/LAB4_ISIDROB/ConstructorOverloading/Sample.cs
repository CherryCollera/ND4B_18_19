﻿namespace ConstructorOverloading
{
    class Sample
    {
        public string firstname, lastname;

        public Sample()
        {
            firstname = "Bryan Albert";
            lastname = "Isidro";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }

    }
}
