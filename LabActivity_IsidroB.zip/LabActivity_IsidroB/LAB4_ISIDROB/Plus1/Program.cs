﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plus1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Solution solution = new Solution(num1, num2);
            Console.WriteLine("\n\nSum = {0}\nDifference = {1}\nProduct = {2}\nQuotient = {3}\nRemainder = {4}", solution.sum, solution.difference, solution.product, solution.quotient, solution.remainder);
            Console.ReadKey();
        }
    }
}
