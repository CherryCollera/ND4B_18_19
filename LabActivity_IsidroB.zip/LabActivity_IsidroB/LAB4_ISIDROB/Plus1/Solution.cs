﻿namespace Plus1
{
    class Solution
    {
        public int sum, difference, product, quotient, remainder;
        public Solution(int x, int y)
        {
            try
            {
                sum = x + y;
                difference = x - y;
                product = x * y;
                quotient = x / y;
                remainder = x % y;
            }
            catch (System.DivideByZeroException ex)
            {
                System.Console.Error.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
