﻿namespace StaticConstructor
{
    class Sample
    {
        public string firstname, lastname;
        static Sample()
        {
            System.Console.WriteLine("Static Constructor");
        }
        public Sample()
        {
            firstname = "Bryan Albert";
            lastname = "Isidro";
        }
    }
}
