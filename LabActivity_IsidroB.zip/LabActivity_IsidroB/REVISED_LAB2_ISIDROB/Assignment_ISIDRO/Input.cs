﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_IsidroB
{
    class Input

    { 
        public void InputDetails() {
            try
            {
                Console.Write("Enter first number:\t");
                DeclaredVariables.num1 = Convert.ToInt16(Console.ReadLine());

                Console.Write("Enter second number:\t");
                DeclaredVariables.num2 = Convert.ToInt16(Console.ReadLine());
            }
            //catch(System.FormatException ex)
            //{
            //    System.Console.Error.WriteLine("Error: " + ex.Message);
            //    throw;
            //}
            catch (System.FormatException)
            {
                System.Console.WriteLine("Invalid user input");
            }
        }
    }
}