﻿namespace Assignment_IsidroB
{
    class Quotient
    {    
        public void Division(int x, int y)
        {
            try
            {
                DeclaredVariables.quotient = x / y;
            }
            catch(System.DivideByZeroException ex)
            {
                System.Console.Error.WriteLine("Error: "+ex.Message);
            }
        }
    }
}
