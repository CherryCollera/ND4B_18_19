﻿namespace Assignment_IsidroB
{
    
    class Difference
    {       
        public void Subtraction(int x, int y)
        {
            try
            {
                DeclaredVariables.difference = x - y;
            }
            catch (System.DivideByZeroException ex)
            {
                System.Console.Error.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
