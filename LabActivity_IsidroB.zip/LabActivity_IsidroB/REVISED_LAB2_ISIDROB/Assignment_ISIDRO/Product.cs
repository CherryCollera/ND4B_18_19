﻿namespace Assignment_IsidroB
{
    class Product
    {
  
        public void Multiplication(int x, int y)
        {
            try
            {
                DeclaredVariables.product = x * y;
            }
            catch (System.DivideByZeroException ex)
            {
                System.Console.Error.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
