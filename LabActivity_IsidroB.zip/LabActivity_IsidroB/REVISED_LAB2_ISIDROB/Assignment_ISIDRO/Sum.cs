﻿namespace Assignment_IsidroB
{
    class Sum
    { 
        public void Addition(int x, int y)
        {
            try
            {
                DeclaredVariables.sum = x + y;
            }
            catch (System.DivideByZeroException ex)
            {
                System.Console.Error.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
