﻿namespace Assignment_IsidroB
{
    class DeclaredVariables
    {
        public static int num1, num2, sum, difference, product, quotient, remainder;
    }
}
