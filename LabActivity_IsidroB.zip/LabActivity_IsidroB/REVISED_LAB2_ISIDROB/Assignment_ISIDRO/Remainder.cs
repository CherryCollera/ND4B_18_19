﻿namespace Assignment_IsidroB
{
    class Remainder
    {
        public void Modulo(int x, int y)
        {
            try
            {
                DeclaredVariables.remainder = x % y;
            }
            catch (System.DivideByZeroException ex)
            {
                System.Console.Error.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
