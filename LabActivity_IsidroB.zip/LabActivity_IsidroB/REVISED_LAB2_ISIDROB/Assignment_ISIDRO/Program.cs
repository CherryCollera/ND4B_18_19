﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_IsidroB
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            i.InputDetails();
         
            Sum sm = new Sum();
            sm.Addition(DeclaredVariables.num1, DeclaredVariables.num2);

            Difference df = new Difference();
            df.Subtraction(DeclaredVariables.num1, DeclaredVariables.num2);

            Product pd = new Product();
            pd.Multiplication(DeclaredVariables.num1, DeclaredVariables.num2);

            Quotient qt = new Quotient();
            qt.Division(DeclaredVariables.num1, DeclaredVariables.num2);

            Remainder rm = new Remainder();
            rm.Modulo(DeclaredVariables.num1, DeclaredVariables.num2);

            Console.WriteLine("\nSum = {0}\nDifference = {1}\nProduct = {2}\nQuotient = {3}\nRemainder = {4}", DeclaredVariables.sum, DeclaredVariables.difference, DeclaredVariables.product, DeclaredVariables.quotient, DeclaredVariables.remainder);

            Console.ReadKey();
        }
    }
}
