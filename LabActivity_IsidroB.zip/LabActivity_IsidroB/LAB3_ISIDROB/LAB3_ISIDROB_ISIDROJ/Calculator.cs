﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB3_ISIDROB_ISIDROJ
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("1");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("3");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("5");
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("6");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("7");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("8");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("9");
        }

        private void btnzero_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText("0");
        }

        private void btnpoint_Click(object sender, EventArgs e)
        {
            txtScreen.AppendText(".");
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtScreen.Clear();
            DeclareVar.total1 = 0;
            DeclareVar.total2 = 0;
            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnplus_Click(object sender, EventArgs e)
        {
            
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtScreen.Text);
            txtScreen.Clear();

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = true;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
        }

        private void btnminus_Click(object sender, EventArgs e)
        {
            
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtScreen.Text);
            txtScreen.Clear();

            DeclareVar.minusButtonClicked = true;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
        }

        private void btnmultiply_Click(object sender, EventArgs e)
        {
            
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtScreen.Text);
            txtScreen.Clear();

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = true;
        }

        private void btndivide_Click(object sender, EventArgs e)
        {
            
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtScreen.Text);
            txtScreen.Clear();

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = true;
            DeclareVar.multiplyButtonClicked = false;
        }

        private void btnequals_Click(object sender, EventArgs e)
        {
            if (DeclareVar.plusButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 + double.Parse(txtScreen.Text);
                DeclareVar.total1 = 0;
                txtScreen.Clear();
                txtScreen.AppendText(Convert.ToString(DeclareVar.total2));
            }
            else if (DeclareVar.minusButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 - double.Parse(txtScreen.Text);
                DeclareVar.total1 = 0;
                txtScreen.Clear();
                txtScreen.AppendText(Convert.ToString(DeclareVar.total2));
            }
            else if( DeclareVar.multiplyButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 * double.Parse(txtScreen.Text);
                DeclareVar.total1 = 0;
                txtScreen.Clear();
                txtScreen.AppendText(Convert.ToString(DeclareVar.total2));
            }
            else
            {
                DeclareVar.total2 = DeclareVar.total1 / double.Parse(txtScreen.Text);
                DeclareVar.total1 = 0;
                txtScreen.Clear();
                txtScreen.AppendText(Convert.ToString(DeclareVar.total2));
            }
          
        }

        private void txtScreen_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
