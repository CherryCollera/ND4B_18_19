﻿
namespace ConstructorOverloading
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Jessica";
            lastname = "Festijo";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
            {

            }
        }
    }
}