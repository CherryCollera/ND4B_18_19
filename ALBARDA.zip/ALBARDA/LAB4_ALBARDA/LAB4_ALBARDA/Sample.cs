﻿

namespace LAB4_ALBARDA
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Joana";
            lastname = "Albarda";
        }
    }
}
