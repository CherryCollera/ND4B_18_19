﻿using System;

namespace PrivateConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Rhomar", "Munar");
            Console.WriteLine(s.firstname + "" + s.lastname);
            Console.ReadLine();
        }
    }
}
