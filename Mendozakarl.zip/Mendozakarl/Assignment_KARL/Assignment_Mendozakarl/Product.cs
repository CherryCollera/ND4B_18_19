﻿

namespace Assignment_PENI
{
    class Product
    {
        public void ComputeProduct()
        {
            DeclareVariable.product = DeclareVariable.num1 * DeclareVariable.num2;
        }
    }
}
