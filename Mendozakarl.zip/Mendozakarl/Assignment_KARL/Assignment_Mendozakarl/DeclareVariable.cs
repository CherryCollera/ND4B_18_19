﻿

namespace Assignment_PENI
{
    class DeclareVariable
    {
        public static int num1, num2, sum, product, difference, qoutient, remainder;
    }
}
