﻿

namespace Assignment_PENI
{
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVariable.difference = DeclareVariable.num1 - DeclareVariable.num2;
        }
    }
}
