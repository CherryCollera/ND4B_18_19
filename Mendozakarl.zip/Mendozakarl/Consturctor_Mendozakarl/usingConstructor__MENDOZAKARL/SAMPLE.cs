﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace usingConstructor__MENDOZAKARL
{
    class SAMPLE
    {
        public string firstname, lastname;
        public SAMPLE()
        {
            firstname = " KARL";
            lastname = " MENDOZA ";
        }
    }
}
