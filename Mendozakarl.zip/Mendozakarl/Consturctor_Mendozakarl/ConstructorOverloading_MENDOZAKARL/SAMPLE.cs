﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading_MENDOZAKARL
{
    class SAMPLE
    {
        public string firstname, lastname;
        public SAMPLE()
        {
            firstname = "KARL";
            lastname = "MENDOZA";
        }

        public SAMPLE(string j, string b)
        {

            firstname = j;
            lastname = b;
        }
    }
}
