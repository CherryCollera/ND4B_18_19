﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor__MENDOZAKARL
{
    class SAMPLE
    {
        public string firstname, lastname;
        static SAMPLE()
        {
            System.Console.WriteLine("Static Constructor");
        }

        public SAMPLE()
        {

            firstname = "KARL";
            lastname = "MENDOZA";
        }
    }
}
