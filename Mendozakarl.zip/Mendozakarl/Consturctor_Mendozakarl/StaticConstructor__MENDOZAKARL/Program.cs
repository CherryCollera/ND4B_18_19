﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor__MENDOZAKARL
{
    class Program
    {
        static void Main(string[] args)
        {
        
            SAMPLE s = new SAMPLE();
            SAMPLE s1 = new SAMPLE();

            Console.WriteLine(s1.firstname + "" + s1.lastname);
            Console.ReadLine();
        }
    }
}
