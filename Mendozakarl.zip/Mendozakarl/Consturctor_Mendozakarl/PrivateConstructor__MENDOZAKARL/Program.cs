﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor__MENDOZAKARL
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE s = new SAMPLE("KARL", "MENDOZA");

            Console.WriteLine("\n" + s.firstname + "\n\n" + s.lastname);
            Console.ReadLine();
        }
    }
}
