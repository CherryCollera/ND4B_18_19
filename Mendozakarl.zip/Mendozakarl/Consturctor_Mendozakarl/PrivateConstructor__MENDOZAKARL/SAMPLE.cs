﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor__MENDOZAKARL
{
    class SAMPLE
    {
        public string firstname, lastname;
        public SAMPLE(string j, string b)
        {
            firstname = j;
            lastname = b;
        }

        private SAMPLE()
        {

            Console.WriteLine(" Private Constructor with no prameters");
        }
    }
}
