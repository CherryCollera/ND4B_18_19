﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consturctor_Mendozakarl
{
    class SAMPLE
    {

        public string firstname, lastname;
        public SAMPLE(string j, string b)
        {
            firstname = j;
            lastname = b;
        }

        public SAMPLE(SAMPLE s)
        {

            firstname = s.firstname;
            lastname = s.lastname;
        }
    }
}
