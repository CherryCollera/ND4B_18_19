﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consturctor_Mendozakarl
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE s = new SAMPLE("Karl", "Mendoza");
            SAMPLE s1 = new SAMPLE(s);
            Console.WriteLine("copy Constructors");
            Console.WriteLine("");
            Console.WriteLine(s);
            Console.WriteLine("\n" + s1.firstname + "\n\n" + s1.lastname);
            Console.ReadLine();
        }
    }
}
