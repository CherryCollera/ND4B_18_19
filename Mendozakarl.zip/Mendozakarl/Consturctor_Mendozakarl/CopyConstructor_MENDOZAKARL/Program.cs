﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor_MENDOZAKARL
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE s1 = new SAMPLE();
            SAMPLE s = new SAMPLE(" KARL", "MENDOZA");
            Console.WriteLine("Constructors Overloading");
            Console.WriteLine(s.firstname + "," + s.lastname);
            Console.WriteLine("\n" + s1.firstname + "\n\n" + s1.lastname);
            Console.ReadLine();
            Console.ReadKey();
        
        }
    }
}
