﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paramiterized_PADILLA
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Parameterized Constructors");
            Console.WriteLine("");
            SAMPLE s = new SAMPLE("CLARICE", "PADILLA");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.secondname);
            Console.ReadLine();
        }
    }
}
