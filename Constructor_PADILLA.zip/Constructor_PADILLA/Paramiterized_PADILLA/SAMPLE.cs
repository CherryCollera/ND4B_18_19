﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paramiterized_PADILLA
{
    class SAMPLE
    {
        public string firstname, secondname;
        public SAMPLE(string j, string p)
        {
            firstname = j;
            secondname = p;
        }
    }
}
