﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor_PADILLA
{
    class Program
    {
        static void Main(string[] args)
        {

            SAMPLE s = new SAMPLE(" CLARICE", "PADILLA ");
            SAMPLE s1 = new SAMPLE();
            Console.WriteLine("copy Constructors");
            Console.WriteLine("");
            Console.WriteLine(s);
            Console.WriteLine("\n" + s1.firstname + "\n\n" + s1.secondname);
            Console.ReadLine();
        }
    }
}
