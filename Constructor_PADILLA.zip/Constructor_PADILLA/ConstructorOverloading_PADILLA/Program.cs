﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading_PADILLA
{
    class Program
    {
        static void Main(string[] args)
        {
            SAMPLE s1 = new SAMPLE();
            SAMPLE s = new SAMPLE(" CLARICE", "PADILLA ");
            Console.WriteLine("Constructors Overloading");
            Console.WriteLine(s.firstname + "," + s.secondname);
            Console.WriteLine("\n" + s1.firstname + "\n\n" + s1.secondname);
            Console.ReadLine();
        }
    }
}
