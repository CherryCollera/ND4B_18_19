﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_CENTENO
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Parameterized Constructors");
            Console.WriteLine("");
            Sample s = new Sample("Leneth", "Centeno");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
