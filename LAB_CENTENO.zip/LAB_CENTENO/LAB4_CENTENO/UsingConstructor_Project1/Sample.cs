﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingConstructor_Project1
{
    class Sample
    {
        public string bday;
        public int y;
        public Sample()
        {
           bday = "March ";
           y    = " 1999 ";
        }
    }
}
