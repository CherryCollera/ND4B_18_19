﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingConstructor_Project1
{
    class Program
    {
        static void Main(string[] args)
        {

            Sample s = new Sample();
            Console.WriteLine("Default Constructors");
            Console.WriteLine("");
            Console.WriteLine(s.bday);
            Console.WriteLine(s.y);
            Console.ReadLine();
            
        
        }
    }
}
