﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor_CENTENO
{
    class Sample
    {
        public string firstname, lastname;
        public Sample(string l, string c)
        {
            firstname = l;
            lastname = c;
        }

        private Sample()
        {

            Console.WriteLine(" Private Constructor with no prameters");
        }
    }
}
