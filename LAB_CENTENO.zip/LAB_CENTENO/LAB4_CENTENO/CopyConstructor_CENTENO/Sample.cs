﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor_CENTENO
{
    class Sample
    {
         public string firstname, lastname;
         public Sample(string l, string c)
        {
            firstname = l;
            lastname = c;
        }

        public Sample(Sample s)
        {

            firstname = s.firstname;
            lastname = s.lastname;
    }
}
