﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading_CENTENO
{
    class Sample
    {
         public string firstname, lastname;
        public Sample()
        {
            firstname = "LENETH";
            lastname = "CENTENO";
        }

        public Sample(string l, string c)
        {

            firstname = l;
            lastname = c;
    }
}
