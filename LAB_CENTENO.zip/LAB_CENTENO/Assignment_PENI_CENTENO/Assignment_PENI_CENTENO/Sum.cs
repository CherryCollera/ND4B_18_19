﻿

namespace Assignment_PENI_CENTENO
{
    class Sum
    {
        public void ComputeSum()
        {
            DeclareVariable.sum = DeclareVariable.num1 + DeclareVariable.num2;
        }
    }
}
