﻿

namespace Assignment_PENI_CENTENO
{
    class Qoutient
    {

        public void ComputeQoutient()
        {
            try
            {
                DeclareVariable.qoutient = DeclareVariable.num1 / DeclareVariable.num2;
            }
            catch (System.DivideByZeroException uwaaaa)
            {
                System.Console.Error.WriteLine("Error:" + uwaaaa.Message);
            }
        }
    }
}
