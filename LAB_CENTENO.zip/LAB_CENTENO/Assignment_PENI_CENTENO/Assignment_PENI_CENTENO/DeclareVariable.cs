﻿

namespace Assignment_PENI_CENTENO
{
    class DeclareVariable
    {
        public static int num1, num2, sum, product, difference, qoutient, remainder;
    }
}
