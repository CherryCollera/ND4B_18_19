﻿

namespace Assignment_PENI_CENTENO
{
    class InputValues
    {
        public void InputValue()
        {
            try
            {
                System.Console.Write("Enter first number:   ");
                DeclareVariable.num1 = System.Convert.ToInt32(System.Console.ReadLine());
                System.Console.Write("\nEnter second number:  ");
                DeclareVariable.num2 = System.Convert.ToInt32(System.Console.ReadLine());
            }
            //catch (System.FormatException ex)
            //{
            // System.Console.Error.WriteLine("Error:" + ex.Message);
            //throw;
            //}
            catch (System.FormatException)
            {
                System.Console.WriteLine("Invalid user input");
            }
        }
    }
}
