﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_PENI_CENTENO
{
    class Program
    {
        static void Main(string[] args)
        {
            InputValues i = new InputValues();
            i.InputValue();

            Sum s = new Sum();
            s.ComputeSum();
            System.Console.WriteLine("\nSum = " + DeclareVariable.sum);
            System.Console.ReadLine();

            Difference d = new Difference();
            d.ComputeDifference();
            System.Console.WriteLine("\nDifference = "+ DeclareVariable.difference);
            System.Console.ReadLine();

            Product p = new Product();
            p.ComputeProduct();
            System.Console.WriteLine("\nProduct =" + DeclareVariable.product);
            System.Console.ReadLine();

            Qoutient q = new Qoutient();
            q.ComputeQoutient();
            System.Console.WriteLine("\nQoutient =" + DeclareVariable.qoutient);
            System.Console.ReadLine();

            Remainder r = new Remainder();
            r.ComputeRemainder();
            System.Console.WriteLine("\nRemainder = "  + DeclareVariable.remainder);
            System.Console.ReadLine();

        }
    }
}
