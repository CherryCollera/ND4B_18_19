﻿

namespace Assignment_PENI_CENTENO
{
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVariable.difference = DeclareVariable.num1 - DeclareVariable.num2;
        }
    }
}
