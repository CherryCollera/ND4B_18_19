﻿

namespace Assignment_PENI_CENTENO
{
    class Product
    {
        public void ComputeProduct()
        {
            DeclareVariable.product = DeclareVariable.num1 * DeclareVariable.num2;
        }
    }
}
