﻿

namespace Assignment_PENI_CENTENO
{
    class Remainder
    {
        public void ComputeRemainder()
        {
            DeclareVariable.remainder = DeclareVariable.num1 % DeclareVariable.num2;
        }
    }
}
