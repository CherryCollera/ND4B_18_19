﻿using System;

namespace ParametizedDenver.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Denver", "Reyes");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
