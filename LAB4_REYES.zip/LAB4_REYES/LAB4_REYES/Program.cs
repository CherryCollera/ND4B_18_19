﻿using System;

namespace LAB4_REYES
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample();
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
