﻿
namespace LAB4_REYES
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Cherry";
            lastname = "Collera";
        }
       }
}
    