﻿using System;

namespace Parametized.cs
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample("Cherry", "Collera");

            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
        }
    }
}
