﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB2_BASA_REYESD
{
    class Program
    {
        static void Main(string[] args)
        {
            Print print = new Print();
            print.PrintDetails();
            

            System.Console.ReadKey();
        }
    }
}
