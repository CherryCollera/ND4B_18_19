﻿

namespace LAB2_BASA_REYESD
{
    class MyProfile
    {
        public string studname, program, year_level;
        public System.DateTime birthday;

        public void MyProfileDetails()
        {
            System.Console.Write("\n\nEnter your name (lastname, firstname): ");
            studname = System.Console.ReadLine();
            System.Console.Write("Enter your name Program: ");
            program = System.Console.ReadLine();
            System.Console.Write("Enter your year level: ");
            year_level = System.Console.ReadLine();
            System.Console.Write("Enter your date of birth: ");
            birthday = System.Convert.ToDateTime(System.Console.ReadLine());
            
        System.Console.WriteLine("\n*****************Displaying the data*****************\n");

        System.Console.WriteLine("Name: " + studname);
        System.Console.WriteLine("Program: " + program);
        System.Console.WriteLine("Year Level: " + year_level);
        System.Console.WriteLine("Birthday " + birthday.ToString("MM/dd/yyyy")+ "\n");
        System.Console.ReadKey();
    }
    }
}

