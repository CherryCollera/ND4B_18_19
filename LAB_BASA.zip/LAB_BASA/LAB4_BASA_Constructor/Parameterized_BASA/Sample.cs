﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_BASA
{
    class Sample
    {
         public string firstname, lastname;
        public Sample(string j, string b)
        {
            firstname = j;
            lastname = b;

        }
    }
}
