﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_BASA
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Parameterized Constructors");
            Console.WriteLine("");
            Sample s = new Sample("John Paul", "Basa");
            Console.WriteLine(s.firstname);
            Console.WriteLine(s.lastname);
            Console.ReadLine();
            System.Console.ReadKey();
        }
    }
}
