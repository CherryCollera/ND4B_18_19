﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ConstructorOverloading_BASA
{
    class Sample
    {
        
     public string firstname, lastname;
        public Sample()
        {
            firstname = "JOHN PAUL";
            lastname = "BASA";
        }

        public Sample(string j, string b)
        {

            firstname = j;
            lastname = b;
        }
    }
}
