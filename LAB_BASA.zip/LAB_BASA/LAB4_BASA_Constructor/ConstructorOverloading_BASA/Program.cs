﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ConstructorOverloading_BASA
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s1 = new Sample();
            Sample s = new Sample(" John Paul", "Basa");
            Console.WriteLine("Constructors Overloading");
            Console.WriteLine(s.firstname + "," + s.lastname);
            Console.WriteLine("\n" + s1.firstname + "\n\n" + s1.lastname);
            Console.ReadLine();
            Console.ReadKey();

        }
    }
}
