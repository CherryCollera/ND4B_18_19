﻿namespace ND4B_LAB3_MASIGLAT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnsExit = new System.Windows.Forms.Button();
            this.btnsequal = new System.Windows.Forms.Button();
            this.btnsquotient = new System.Windows.Forms.Button();
            this.btnsproduct = new System.Windows.Forms.Button();
            this.btnsminus = new System.Windows.Forms.Button();
            this.btnsplus = new System.Windows.Forms.Button();
            this.btnsclear = new System.Windows.Forms.Button();
            this.btnsdot = new System.Windows.Forms.Button();
            this.btns0 = new System.Windows.Forms.Button();
            this.btns9 = new System.Windows.Forms.Button();
            this.btns8 = new System.Windows.Forms.Button();
            this.btns7 = new System.Windows.Forms.Button();
            this.btns6 = new System.Windows.Forms.Button();
            this.btns5 = new System.Windows.Forms.Button();
            this.btns4 = new System.Windows.Forms.Button();
            this.btns3 = new System.Windows.Forms.Button();
            this.btns2 = new System.Windows.Forms.Button();
            this.btns1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnsExit
            // 
            this.btnsExit.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsExit.Location = new System.Drawing.Point(29, 338);
            this.btnsExit.Name = "btnsExit";
            this.btnsExit.Size = new System.Drawing.Size(57, 36);
            this.btnsExit.TabIndex = 100;
            this.btnsExit.Text = "Exit";
            this.btnsExit.UseVisualStyleBackColor = true;
            this.btnsExit.Click += new System.EventHandler(this.btnsExit_Click);
            // 
            // btnsequal
            // 
            this.btnsequal.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsequal.Location = new System.Drawing.Point(233, 338);
            this.btnsequal.Name = "btnsequal";
            this.btnsequal.Size = new System.Drawing.Size(56, 36);
            this.btnsequal.TabIndex = 99;
            this.btnsequal.Text = "=";
            this.btnsequal.UseVisualStyleBackColor = true;
            this.btnsequal.Click += new System.EventHandler(this.btnsequal_Click);
            // 
            // btnsquotient
            // 
            this.btnsquotient.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsquotient.Location = new System.Drawing.Point(233, 289);
            this.btnsquotient.Name = "btnsquotient";
            this.btnsquotient.Size = new System.Drawing.Size(57, 36);
            this.btnsquotient.TabIndex = 98;
            this.btnsquotient.Text = "/";
            this.btnsquotient.UseVisualStyleBackColor = true;
            this.btnsquotient.Click += new System.EventHandler(this.btnsquotient_Click);
            // 
            // btnsproduct
            // 
            this.btnsproduct.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsproduct.Location = new System.Drawing.Point(233, 237);
            this.btnsproduct.Name = "btnsproduct";
            this.btnsproduct.Size = new System.Drawing.Size(57, 36);
            this.btnsproduct.TabIndex = 97;
            this.btnsproduct.Text = "*";
            this.btnsproduct.UseVisualStyleBackColor = true;
            this.btnsproduct.Click += new System.EventHandler(this.btnsproduct_Click);
            // 
            // btnsminus
            // 
            this.btnsminus.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsminus.Location = new System.Drawing.Point(233, 192);
            this.btnsminus.Name = "btnsminus";
            this.btnsminus.Size = new System.Drawing.Size(57, 36);
            this.btnsminus.TabIndex = 96;
            this.btnsminus.Text = "-";
            this.btnsminus.UseVisualStyleBackColor = true;
            this.btnsminus.Click += new System.EventHandler(this.btnsminus_Click);
            // 
            // btnsplus
            // 
            this.btnsplus.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsplus.Location = new System.Drawing.Point(233, 140);
            this.btnsplus.Name = "btnsplus";
            this.btnsplus.Size = new System.Drawing.Size(57, 36);
            this.btnsplus.TabIndex = 95;
            this.btnsplus.Text = "+";
            this.btnsplus.UseVisualStyleBackColor = true;
            this.btnsplus.Click += new System.EventHandler(this.btnsplus_Click);
            // 
            // btnsclear
            // 
            this.btnsclear.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsclear.Location = new System.Drawing.Point(155, 289);
            this.btnsclear.Name = "btnsclear";
            this.btnsclear.Size = new System.Drawing.Size(57, 36);
            this.btnsclear.TabIndex = 94;
            this.btnsclear.Text = "Clear";
            this.btnsclear.UseVisualStyleBackColor = true;
            this.btnsclear.Click += new System.EventHandler(this.btnsclear_Click);
            // 
            // btnsdot
            // 
            this.btnsdot.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsdot.Location = new System.Drawing.Point(92, 289);
            this.btnsdot.Name = "btnsdot";
            this.btnsdot.Size = new System.Drawing.Size(57, 36);
            this.btnsdot.TabIndex = 93;
            this.btnsdot.Text = ".";
            this.btnsdot.UseVisualStyleBackColor = true;
            this.btnsdot.Click += new System.EventHandler(this.btnsdot_Click);
            // 
            // btns0
            // 
            this.btns0.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns0.Location = new System.Drawing.Point(29, 289);
            this.btns0.Name = "btns0";
            this.btns0.Size = new System.Drawing.Size(57, 36);
            this.btns0.TabIndex = 92;
            this.btns0.Text = "0";
            this.btns0.UseVisualStyleBackColor = true;
            this.btns0.Click += new System.EventHandler(this.btns0_Click);
            // 
            // btns9
            // 
            this.btns9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns9.Location = new System.Drawing.Point(155, 237);
            this.btns9.Name = "btns9";
            this.btns9.Size = new System.Drawing.Size(57, 36);
            this.btns9.TabIndex = 91;
            this.btns9.Text = "9";
            this.btns9.UseVisualStyleBackColor = true;
            this.btns9.Click += new System.EventHandler(this.btns9_Click);
            // 
            // btns8
            // 
            this.btns8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns8.Location = new System.Drawing.Point(92, 237);
            this.btns8.Name = "btns8";
            this.btns8.Size = new System.Drawing.Size(57, 36);
            this.btns8.TabIndex = 90;
            this.btns8.Text = "8";
            this.btns8.UseVisualStyleBackColor = true;
            this.btns8.Click += new System.EventHandler(this.btns8_Click);
            // 
            // btns7
            // 
            this.btns7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns7.Location = new System.Drawing.Point(29, 237);
            this.btns7.Name = "btns7";
            this.btns7.Size = new System.Drawing.Size(57, 36);
            this.btns7.TabIndex = 89;
            this.btns7.Text = "7";
            this.btns7.UseVisualStyleBackColor = true;
            this.btns7.Click += new System.EventHandler(this.btns7_Click);
            // 
            // btns6
            // 
            this.btns6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns6.Location = new System.Drawing.Point(155, 192);
            this.btns6.Name = "btns6";
            this.btns6.Size = new System.Drawing.Size(57, 36);
            this.btns6.TabIndex = 88;
            this.btns6.Text = "6";
            this.btns6.UseVisualStyleBackColor = true;
            this.btns6.Click += new System.EventHandler(this.btns6_Click);
            // 
            // btns5
            // 
            this.btns5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns5.Location = new System.Drawing.Point(92, 192);
            this.btns5.Name = "btns5";
            this.btns5.Size = new System.Drawing.Size(57, 36);
            this.btns5.TabIndex = 87;
            this.btns5.Text = "5";
            this.btns5.UseVisualStyleBackColor = true;
            this.btns5.Click += new System.EventHandler(this.btns5_Click);
            // 
            // btns4
            // 
            this.btns4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns4.Location = new System.Drawing.Point(29, 192);
            this.btns4.Name = "btns4";
            this.btns4.Size = new System.Drawing.Size(57, 36);
            this.btns4.TabIndex = 86;
            this.btns4.Text = "4";
            this.btns4.UseVisualStyleBackColor = true;
            this.btns4.Click += new System.EventHandler(this.btns4_Click);
            // 
            // btns3
            // 
            this.btns3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns3.Location = new System.Drawing.Point(155, 140);
            this.btns3.Name = "btns3";
            this.btns3.Size = new System.Drawing.Size(57, 36);
            this.btns3.TabIndex = 85;
            this.btns3.Text = "3";
            this.btns3.UseVisualStyleBackColor = true;
            this.btns3.Click += new System.EventHandler(this.btns3_Click);
            // 
            // btns2
            // 
            this.btns2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns2.Location = new System.Drawing.Point(92, 140);
            this.btns2.Name = "btns2";
            this.btns2.Size = new System.Drawing.Size(57, 36);
            this.btns2.TabIndex = 84;
            this.btns2.Text = "2";
            this.btns2.UseVisualStyleBackColor = true;
            this.btns2.Click += new System.EventHandler(this.btns2_Click);
            // 
            // btns1
            // 
            this.btns1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btns1.Location = new System.Drawing.Point(29, 140);
            this.btns1.Name = "btns1";
            this.btns1.Size = new System.Drawing.Size(57, 36);
            this.btns1.TabIndex = 83;
            this.btns1.Text = "1";
            this.btns1.UseVisualStyleBackColor = true;
            this.btns1.Click += new System.EventHandler(this.btns1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(29, 86);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(261, 24);
            this.textBox1.TabIndex = 82;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 55);
            this.label1.TabIndex = 81;
            this.label1.Text = "Calculator";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 395);
            this.Controls.Add(this.btnsExit);
            this.Controls.Add(this.btnsequal);
            this.Controls.Add(this.btnsquotient);
            this.Controls.Add(this.btnsproduct);
            this.Controls.Add(this.btnsminus);
            this.Controls.Add(this.btnsplus);
            this.Controls.Add(this.btnsclear);
            this.Controls.Add(this.btnsdot);
            this.Controls.Add(this.btns0);
            this.Controls.Add(this.btns9);
            this.Controls.Add(this.btns8);
            this.Controls.Add(this.btns7);
            this.Controls.Add(this.btns6);
            this.Controls.Add(this.btns5);
            this.Controls.Add(this.btns4);
            this.Controls.Add(this.btns3);
            this.Controls.Add(this.btns2);
            this.Controls.Add(this.btns1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsExit;
        private System.Windows.Forms.Button btnsequal;
        private System.Windows.Forms.Button btnsquotient;
        private System.Windows.Forms.Button btnsproduct;
        private System.Windows.Forms.Button btnsminus;
        private System.Windows.Forms.Button btnsplus;
        private System.Windows.Forms.Button btnsclear;
        private System.Windows.Forms.Button btnsdot;
        private System.Windows.Forms.Button btns0;
        private System.Windows.Forms.Button btns9;
        private System.Windows.Forms.Button btns8;
        private System.Windows.Forms.Button btns7;
        private System.Windows.Forms.Button btns6;
        private System.Windows.Forms.Button btns5;
        private System.Windows.Forms.Button btns4;
        private System.Windows.Forms.Button btns3;
        private System.Windows.Forms.Button btns2;
        private System.Windows.Forms.Button btns1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
    }
}

