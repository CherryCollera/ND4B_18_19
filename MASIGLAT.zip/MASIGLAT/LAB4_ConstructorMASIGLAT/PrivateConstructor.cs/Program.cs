﻿using System;

namespace PrivateConstructor.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Camila", "Mendez");
            Console.WriteLine(s.firstname + "" + s.lastname);
            Console.ReadLine();
        }
    }
}
