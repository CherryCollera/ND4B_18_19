﻿
namespace LAB4_ConstructorMASIGLAT
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Simon";
            lastname = "Xander";
        }
    }
}
