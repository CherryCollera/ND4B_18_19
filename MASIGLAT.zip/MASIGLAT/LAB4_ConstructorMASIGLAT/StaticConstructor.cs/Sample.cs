﻿
namespace StaticConstructor.cs
{
    class Sample
    {
        public string firstname, lastname;

        static Sample()
        {
            System.Console.WriteLine("Static constructor");
        }
        public Sample()
        {
            firstname = "Shawn";
            lastname = "Mendez";
        }
    }
}
